
"use strict";

let oddEvenCheck = require('./oddEvenCheck.js')
let brightnessCheck = require('./brightnessCheck.js')

module.exports = {
  oddEvenCheck: oddEvenCheck,
  brightnessCheck: brightnessCheck,
};
