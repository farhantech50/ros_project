#!/usr/bin/env python3

import rospy
from ros_project.srv import brightnessCheck, brightnessCheckResponse

def call_back(req):
    if (req.val > 25):
        check = True
    else:
        check = False
    return brightnessCheckResponse(check)


if __name__ == '__main__':
    try:
        rospy.init_node("brightness_check_node")
        rospy.Service("brightness_check",brightnessCheck,call_back)
        rospy.spin()

    except Exception as e:
        print(repr(e))
        pass
