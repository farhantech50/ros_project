#!/usr/bin/env python3

import rospy, random
from std_msgs.msg import Float64

def rpm_pub():
    rospy.init_node("rpm")
    pub = rospy.Publisher("rpmNode", Float64, queue_size=10)
    rate = rospy.Rate(2)
    while not rospy.is_shutdown():
        rpm = random.randint(5,20)
        pub.publish(rpm)
        rate.sleep()
if __name__ =='__main__':
    try:
        rpm_pub()
    except rospy.ROSInterruptException:
        pass