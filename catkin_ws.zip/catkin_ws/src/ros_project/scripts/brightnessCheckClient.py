#!/usr/bin/env python3

import rospy, random
from ros_project.srv import brightnessCheck
from std_msgs.msg import String,Bool 


if __name__ == '__main__':
    try:
        rospy.init_node("brightness_check_node")
        service = rospy.ServiceProxy("brightness_check",brightnessCheck)
        publisher = rospy.Publisher("brightnessNode",Bool,queue_size=10)
        
        while not rospy.is_shutdown():
            res_obj = service(random.randint(0,50))
            publisher.publish(res_obj.result)  
            rospy.Rate(3).sleep()          

    except Exception as e:
        print(repr(e))
        pass