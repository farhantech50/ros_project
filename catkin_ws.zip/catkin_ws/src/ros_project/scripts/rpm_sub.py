#!/usr/bin/env python3

import rospy, time
from std_msgs.msg import String,Float64,Bool

rpm=0
lightState = None
wheel_radius = rospy.get_param("/wheel_radius")
pub = rospy.Publisher("speedNode", String, queue_size=10)

def calc_speed(rpmVal,publisher):
    wheel_radius = rospy.get_param(("/wheel_radius"))
    speed = rpm * 2.00 * 3.14159 / 60.00 * wheel_radius
    if (lightState==True):
        publisher.publish("Rover is moving with speed: "+str(round(speed,2))+" Headlight: [ON]")
    elif (lightState==False):
        publisher.publish("Rover is moving with speed: "+str(round(speed,2))+" Headlight: [OFF]")

def callbackRP(data):
    global rpm
    rpm=data.data
    

def callbackBG(data):
    global lightState
    lightState=data.data

def listener():
    rospy.Subscriber("rpmNode", Float64, callbackRP) 
    rospy.Subscriber("brightnessNode",Bool,callbackBG)
    
    

if __name__ == '__main__':
    try:
        rospy.init_node("listener")
        while True:
            listener()
            calc_speed(rpm, pub)
            time.sleep(1)
    except Exception as e:
        print(repr(e))
        pass


    	
    	
